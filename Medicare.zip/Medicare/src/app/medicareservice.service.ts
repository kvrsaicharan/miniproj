import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MedicareserviceService {
  currentTestId:number=0;
  currentDoctorMobile:number=0;
  constructor(private http:HttpClient) { }

  
  addUserRegister(data:any){
    console.log("service"+data)
    let userinput={"mobileNo":data.mobile,
    "userName":data.username,
     "gender":data.gender,
    "role":data.role,
   "password":data.password,
   "email":data.email,
  "securityquestion":data.securityQuestion,
"answer":data.answer}
   console.log(data.mobile);
   console.log("service"+data.role);
    return this.http.post("http://localhost:9989/userregistration/addnewuser",userinput);
  }

  userlogin(mobile,password){
    return this.http.get("http://localhost:9989/userregistration/validate/"+mobile+"/"+password)
  }

  getRole(mobile){
    return this.http.get("http://localhost:9989/userregistration/getuserrole/"+mobile);
  }

  //regarding doctors
  adddoctors(data:any){
    console.log("data added is"+data)
   let input={
      "doctorMobile":data.mobile,
	"doctorName":data.name,
	"doctorSpecalization":data.specilization,
	"availableTiming":data.timmings,
	"doctorLocation":data.location,
	"doctorDisease":data.disease

    }
    return this.http.post("http://localhost:9989/doctorsdetails/adddoctor",input)
  }

  addmedicines(data:any){
    console.log("data medicines is"+data)
    let input={
      "medicineId": data.id,
    "medicineName": data.name,
    "medicineUsage": data.usage,
    "medicineReason": data.reason,
    "medicineValidity": data.validity,
    "medicinePrice": data.price

    }
    return this.http.post("http://localhost:9989/medicine/addMedicine",input)
  }
  getAllDoctors()
  {
    return this.http.get("http://localhost:9989/doctorsdetails/showalldoctors")
  }
  deleteDoctor(mobileNo:any)
  {
    console.log("doctor mobile is"+mobileNo)
    return this.http.delete("http://localhost:9989/doctorsdetails/deletedoctor/"+mobileNo)
  }
  getAllMedicines()
  {
    return this.http.get("http://localhost:9989/medicine/getAllMedicine")
  }
  deleteMedicines(medicineId:any)
  {
    return this.http.delete("http://localhost:9989/medicine/deleteMedicine/"+medicineId)
  }

  getPrice(mobile:number,price:number){
    return this.http.get("http://localhost:9989/medicine/getprice/"+mobile+"/"+price)
  }
  setTotalPrice(mobile:number){
    return this.http.get("http://localhost:9989/medicine/setprice/"+mobile);
  }

  updateMedicines(id:number,price:number){
    console.log("in update service"+id);
    console.log("in update service"+price);
   return this.http.put("http://localhost:9989/medicine/updatemedicine/"+id+"/"+price,+id);
  }

  updateDoctors(mobile:number,timming:any,location:any){
    return this.http.put("http://localhost:9989/doctorsdetails/updatedoctors/"+mobile+"/"+timming+"/"+location,+mobile);
  }
}
