import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-deletemedicines',
  templateUrl: './deletemedicines.component.html',
  styleUrls: ['./deletemedicines.component.css']
})
export class DeletemedicinesComponent implements OnInit {
  result:any=[];
  data:any=[];

  constructor(private service:MedicareserviceService) { }
  deleteMedicines(medicineId:any)
  {
    console.log("in delete doctor ts file"+medicineId);
    let index=this.data.indexOf(medicineId);
    this.data.splice(index,1);
     window.location.reload(); 
      this.service.deleteMedicines(medicineId).subscribe();

  }

  ngOnInit() {
    this.service.getAllMedicines().subscribe(result=>{this.data=result;
    })
  }

}
