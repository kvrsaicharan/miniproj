import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-updatemedicines',
  templateUrl: './updatemedicines.component.html',
  styleUrls: ['./updatemedicines.component.css']
})
export class UpdatemedicinesComponent implements OnInit {

  constructor(private service:MedicareserviceService) { }
  model:any={};
  id:number;
  price:number;
  testId:number;
  show:boolean=false;
  /* method for updating tests */
    updateMedicine(){
    console.log("in ts file"+this.id)
    this.show=true;
      
    this.service.updateMedicines(this.testId,this.price).subscribe();
    
  }
    ngOnInit() {
      this.testId=this.service.currentTestId;
    }
  
}
