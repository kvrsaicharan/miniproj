import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  result :boolean=false;;
  model:any={}

 
  constructor(private router:Router,private service:MedicareserviceService) { }
 
 
  addUser():any{
    this.result=true;
      console.log(this.model);
    this.service.addUserRegister(this.model).subscribe();

   
  }
 
  
  ngOnInit() {
  }

}
