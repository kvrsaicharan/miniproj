import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-customerviewdoctors',
  templateUrl: './customerviewdoctors.component.html',
  styleUrls: ['./customerviewdoctors.component.css']
})
export class CustomerviewdoctorsComponent implements OnInit {
data:any=[];
  constructor(private service:MedicareserviceService) { }
bookDoctor(){

}
  ngOnInit() {
    this.service.getAllDoctors().subscribe(result=>{this.data=result;
    })
   
  }

  }


