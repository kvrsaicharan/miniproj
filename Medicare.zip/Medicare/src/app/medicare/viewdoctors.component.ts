import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewdoctors',
  templateUrl: './viewdoctors.component.html',
  styleUrls: ['./viewdoctors.component.css']
})
export class ViewdoctorsComponent implements OnInit {

  result:any=[];
  data:any=[];

  constructor(private service:MedicareserviceService,private router:Router) { }
  deleteDoctor(mobileNo:any)
  {
    console.log("in delete doctor ts file"+mobileNo);
    let index=this.data.indexOf(mobileNo);
    this.data.splice(index,1);
     window.location.reload(); 
      this.service.deleteDoctor(mobileNo).subscribe();

  }
  updateDoctor(mobileNo:any){
    this.service.currentDoctorMobile=mobileNo;
    this.router.navigate(['/updatedoctors'])
  }

  ngOnInit() {
    this.service.getAllDoctors().subscribe(result=>{this.data=result;
    });

  }

}
