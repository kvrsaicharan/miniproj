import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewmedicines',
  templateUrl: './viewmedicines.component.html',
  styleUrls: ['./viewmedicines.component.css']
})
export class ViewmedicinesComponent implements OnInit {

  result:any=[];
  data:any=[];
  show:boolean=false;

  constructor(private service:MedicareserviceService,private router:Router) { }
  deleteMedicines(medicineId:any)
  {
    console.log("in delete doctor ts file"+medicineId);
    let index=this.data.indexOf(medicineId);
    this.data.splice(index,1);
     window.location.reload(); 
      this.service.deleteMedicines(medicineId).subscribe();

  }
  updateMedicines(medicineId:any){
    console.log(medicineId)
  this.service.currentTestId=medicineId;
  this.show=true;
  this.router.navigate(['/updatemedicines'])
  }

  ngOnInit() {
    this.service.getAllMedicines().subscribe(result=>{this.data=result;
    })
  }

}
