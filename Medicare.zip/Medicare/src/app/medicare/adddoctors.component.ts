import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-adddoctors',
  templateUrl: './adddoctors.component.html',
  styleUrls: ['./adddoctors.component.css']
})
export class AdddoctorsComponent implements OnInit {
model:any={};
result:boolean=false;
  constructor(private service:MedicareserviceService) { }
  addDoctors(){
    this.result=true;
this.service.adddoctors(this.model).subscribe();
}
  ngOnInit() {
  }

}
