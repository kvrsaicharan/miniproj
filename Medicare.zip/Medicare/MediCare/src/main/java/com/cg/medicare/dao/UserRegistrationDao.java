package com.cg.medicare.dao;

import java.util.List;

import com.cg.medicare.dto.UserRegistration;

public interface UserRegistrationDao {
	public boolean validateMobileandAnswer(Long mobileno, String answer);
	public boolean validateUserLogin(Long mobile, String password); 
	public UserRegistration addNewUser(UserRegistration user);
	public void updatepassword(Long mobile, String pwd);
	public List<UserRegistration> getAllUserDeatils();
	public void deleteUser(Long mobileNo);
	public String getAdminAndUserDetails(Long mobile, String password);
	public String getRole(Long mobile);

}
