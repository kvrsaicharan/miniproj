package com.cg.medicare.dao;

import java.util.List;

import com.cg.medicare.dto.Medicines;

public interface MedicineDao {
	public List<Medicines> showAllMedicines();
	public Medicines addMedicine(Medicines medicine);
	public List<Medicines> searchByMedicineName(String medicineName);
	public List<Medicines> searchByMedicineReason(String medicineReason);
	public void deleteMedicine(Long medicineId); 
	public Medicines updateMedicine(Long medicineId,Integer medicinePrice);
	public Integer getPrice(Long customermobile,Integer price);
	public void setprice(Long customermobile);
	

}
