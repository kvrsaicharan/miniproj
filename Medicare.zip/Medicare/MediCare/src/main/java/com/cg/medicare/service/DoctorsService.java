package com.cg.medicare.service;

import java.util.List;

import com.cg.medicare.dto.Doctors;

public interface DoctorsService {

	public List<Doctors> showAllDoctors();
	public Doctors findDoctor(Long doctorMobile);
	public Doctors addDoctors(Doctors doctor);
	public List<Doctors> getDoctorByDisease(String doctorDisease);
	public void deleteDoctor(Long doctorMobile); 
	public Doctors updateDoctor(Long doctorMobile,String doctorTiming,String doctorLocation);
	

}
