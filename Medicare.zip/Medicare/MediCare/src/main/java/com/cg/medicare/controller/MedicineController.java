package com.cg.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.medicare.dto.Medicines;
import com.cg.medicare.service.MedicineService;

@RestController
@RequestMapping("/medicine")
@CrossOrigin("http://localhost:4200")
public class MedicineController {
	@Autowired
	MedicineService medicineService;
	
	 
	
	@PostMapping("/addMedicine")
	public Medicines addMedicine(@RequestBody Medicines medicine) {
		return medicineService.addMedicine(medicine);
	}
	
	@GetMapping("/getAllMedicine")
	public List<Medicines> getAllMedicines(){
		return medicineService.showAllMedicines();
	}
	
	@GetMapping("/getMedicineByName/{medicinename}")
	public List<Medicines> getMedicineByName(@PathVariable("medicinename") String name) {
		return medicineService.searchByMedicineName(name);
	}
	
	@GetMapping("/getMedicineByReason/{medicineReason}")
	public List<Medicines> getMedicineByReason(@PathVariable("medicineReason") String reason) {
		return medicineService.searchByMedicineReason(reason);
	}
	
	@PutMapping("/updatemedicine/{medicineId}/{price}")
	public Medicines updateMedicinePrice(@PathVariable("medicineId") Long id,@PathVariable("price") Integer price) {
		return medicineService.updateMedicine(id, price);
	}
	
	@DeleteMapping("/deleteMedicine/{medicineId}")
	public void DeleteMedicine(@PathVariable("medicineId") Long id) {
		medicineService.deleteMedicine(id);
	}
	
	@GetMapping("/getprice/{customermobile}/{price}")
	public Integer getPrice(@PathVariable("customermobile") Long cmobile,@PathVariable("price") Integer price) {
		System.out.println("in get price controller"+cmobile+price);
		return medicineService.getPrice(cmobile, price);
	}
	@GetMapping("/setprice/{customermobile}")
		public void setprice(@PathVariable("customermobile") Long cmobile) {
		medicineService.setprice(cmobile);
		}

}
