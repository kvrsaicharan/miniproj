package com.cg.medicare.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "medicines_data")
public class Medicines {
	@Id
	@Indexed(name="_id")
	private Long medicineId;
	private String medicineName;
	private String medicineUsage;
	private String medicineReason;
	private String medicineValidity;
	private Integer medicinePrice;

	
	public Long getMedicineId() {
		return medicineId;
	}
	public void setMedicineId(Long medicineId) {
		this.medicineId = medicineId;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getMedicineUsage() {
		return medicineUsage;
	}
	public void setMedicineUsage(String medicineUsage) {
		this.medicineUsage = medicineUsage;
	}
	public String getMedicineReason() {
		return medicineReason;
	}
	public void setMedicineReason(String medicineReason) {
		this.medicineReason = medicineReason;
	}
	public String getMedicineValidity() {
		return medicineValidity;
	}
	public void setMedicineValidity(String medicineValidity) {
		this.medicineValidity = medicineValidity;
	}
	public Integer getMedicinePrice() {
		return medicinePrice;
	}
	public void setMedicinePrice(Integer medicinePrice) {
		this.medicinePrice = medicinePrice;
	}
	
	public Medicines() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Medicines(Long medicineId, String medicineName, String medicineUsage, String medicineReason,
			String medicineValidity, Integer medicinePrice) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.medicineUsage = medicineUsage;
		this.medicineReason = medicineReason;
		this.medicineValidity = medicineValidity;
		this.medicinePrice = medicinePrice;
	
	}
	@Override
	public String toString() {
		return "Medicines [medicineId=" + medicineId + ", medicineName=" + medicineName + ", medicineUsage="
				+ medicineUsage + ", medicineReason=" + medicineReason + ", medicineValidity=" + medicineValidity
				+ ", medicinePrice=" + medicinePrice +  "]";
	}
	
	

}
