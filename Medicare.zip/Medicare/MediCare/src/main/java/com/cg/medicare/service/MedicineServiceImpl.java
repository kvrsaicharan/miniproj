package com.cg.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medicare.dao.MedicineDao;
import com.cg.medicare.dto.Medicines;

@Service
public class MedicineServiceImpl implements MedicineService{
	@Autowired
	MedicineDao medicineDao;

	@Override
	public List<Medicines> showAllMedicines() {
		// TODO Auto-generated method stub
		return medicineDao.showAllMedicines();
	}

	@Override
	public Medicines addMedicine(Medicines medicine) {
		// TODO Auto-generated method stub
		return medicineDao.addMedicine(medicine);
	}

	@Override
	public List<Medicines> searchByMedicineName(String medicineName) {
		// TODO Auto-generated method stub
		return medicineDao.searchByMedicineName(medicineName);
	}

	@Override
	public List<Medicines> searchByMedicineReason(String medicineReason) {
		// TODO Auto-generated method stub
		return medicineDao.searchByMedicineReason(medicineReason);
	}

	@Override
	public void deleteMedicine(Long medicineId) {
		// TODO Auto-generated method stub
		medicineDao.deleteMedicine(medicineId);
		
	}

	@Override
	public Medicines updateMedicine(Long medicineId, Integer medicinePrice) {
		// TODO Auto-generated method stub
		return medicineDao.updateMedicine(medicineId, medicinePrice);
	}

	@Override
	public Integer getPrice(Long customermobile, Integer price) {
		// TODO Auto-generated method stub
		return medicineDao.getPrice(customermobile, price);
	}

	@Override
	public void setprice(Long customermobile) {
		// TODO Auto-generated method stub
		medicineDao.setprice(customermobile);
	};
	

}
