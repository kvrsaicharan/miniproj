package com.cg.medicare.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.medicare.dto.UserRegistration;

@Repository
public class UserRegistrationDaoImpl implements UserRegistrationDao{

	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public boolean validateMobileandAnswer(Long mobileno, String answer) {
		// TODO Auto-generated method stub
		boolean flag=false;
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobileno)) {
				if(details.getAnswer().equalsIgnoreCase(answer)) {
					flag=true;
				}
			}
		}
		return flag;
	}

	@Override
	public boolean validateUserLogin(Long mobile, String password) {
		boolean flag=false;
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobile)) {
				if(details.getPassword().equalsIgnoreCase(password)) {
					flag=true;
				}
			}
		}
		return flag;
	}

	@Override
	public UserRegistration addNewUser(UserRegistration user) {
		// TODO Auto-generated method stub
		
		return  mongotemplate.insert(user);
	}

	@Override
	public void updatepassword(Long mobile, String pwd) {
		// TODO Auto-generated method stub
		System.out.println("before password is"+pwd);
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobile)) {
				details.setPassword(pwd);
				System.out.println("after password"+details.getPassword());
			}
		}
		
		
	}

	@Override
	public List<UserRegistration> getAllUserDeatils() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(UserRegistration.class);
	}

	@Override
	public void deleteUser(Long mobileNo) {
		// TODO Auto-generated method stub
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobileNo)) {
				mongotemplate.remove(details);
			}
		}
		
	}

	@Override
	public String getAdminAndUserDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		String roles="";
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobile)) {
				if(details.getPassword().equalsIgnoreCase(password)) {
					roles=details.getRole();
				}
			}
		}
		return roles;
	}

	@Override
	public String getRole(Long mobile) {
		// TODO Auto-generated method stub
		List<UserRegistration>user1=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration user:user1 ) {
			if(user.getMobileNo().equals(mobile)) {
		System.out.println("user role is"+user.getRole());
		return user.getRole();
		
		}
		}
		return null;
	}

	
	

}
